

CREATE PROCEDURE [dbo].[getAllCourses] 
    @reg_no varchar(100),
	@course varchar(100),
	@lectures_no int,
	@today varchar(100),
	@semday1 varchar(100)
AS
BEGIN
	
	Declare @extra_C int
	Declare @extra_H int

	Select @extra_C= Count(*) from( select combined_date  from dbo.combine_holidays WHERE date BETWEEN @semday1 AND @today AND course like '%'+@course+'%' AND status='CANCELLATION' GROUP BY combined_date) AS test

	Select @extra_H= Count(*) from( select combined_date  from dbo.combine_holidays WHERE date BETWEEN @semday1 AND @today AND course like '%'+@course+'%' AND status='HOLIDAY' GROUP BY combined_date) AS test

	Declare @program varchar(100)
	SELECT @program= dbo.DEPARTMENTS.DEPTNAME from dbo.USERINFO INNER JOIN dbo.DEPARTMENTS ON dbo.USERINFO.DEFAULTDEPTID=dbo.DEPARTMENTS.DEPTID WHERE dbo.USERINFO.SSN=@reg_no GROUP BY dbo.DEPARTMENTS.DEPTNAME
	SELECT dbo.attendance.courseId,CONVERT(DECIMAL(20,2),CONVERT(DECIMAL(20,2),COUNT(dbo.attendance.status)+@extra_C+@extra_H)*CONVERT(DECIMAL(20,2),CONVERT(DECIMAL(20,2),100)/CONVERT(DECIMAL(20,2),@lectures_no))) AS PERCENTAGE,dbo.courses.course_name FROM dbo.attendance INNER JOIN dbo.courses ON dbo.attendance.courseId=dbo.courses.course WHERE dbo.attendance.courseId like  '%'+@course+'%' AND dbo.attendance.validity='VALID' AND dbo.attendance.status=1 AND dbo.attendance.reg_no=@reg_no AND dbo.attendance.title='student' AND dbo.attendance.category='CLASS' AND dbo.courses.program=@program GROUP BY dbo.attendance.courseId,dbo.courses.course_name
    
END
go

