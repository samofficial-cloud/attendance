

CREATE PROCEDURE [dbo].[getAllCoursesAndLectures_noStudent]
	@reg_no varchar(100)
	
AS
BEGIN
	Declare @program varchar(100)
	SELECT @program= dbo.DEPARTMENTS.DEPTNAME from dbo.USERINFO INNER JOIN dbo.DEPARTMENTS ON dbo.USERINFO.DEFAULTDEPTID=dbo.DEPARTMENTS.DEPTID WHERE dbo.USERINFO.SSN=@reg_no GROUP BY dbo.DEPARTMENTS.DEPTNAME
	select dbo.attendance.courseId,courses.lectures_no FROM dbo.attendance INNER JOIN dbo.courses ON dbo.attendance.courseId=dbo.courses.course WHERE dbo.attendance.reg_no=@reg_no AND dbo.attendance.title='student' AND dbo.attendance.validity='VALID' AND dbo.attendance.status=1 AND dbo.attendance.category='CLASS' AND dbo.courses.program=@program GROUP BY dbo.attendance.courseId,dbo.courses.lectures_no
    
END
go

