


CREATE PROCEDURE [dbo].[extra_countC] 
	@course varchar(100),
	@today varchar(100),
	@semday1 varchar(100)
AS
BEGIN
	
SELECT DISTINCT COUNT(*) OVER () AS TotalRecords

from dbo.combine_holidays WHERE combined_date BETWEEN @semday1 AND @today AND course like '%'+@course+'%' AND status='CANCELLATION' GROUP BY date
   
   
   


END
go

