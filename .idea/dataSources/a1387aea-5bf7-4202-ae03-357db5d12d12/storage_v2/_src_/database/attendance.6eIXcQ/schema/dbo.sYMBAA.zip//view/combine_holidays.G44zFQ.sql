

CREATE VIEW [dbo].[combine_holidays] AS
SELECT dbo.timetables.day, dbo.timetables.venue,dbo.timetables.course,dbo.timetables.fromTime,dbo.timetables.toTime,dbo.timetables.criteria,(cast(dbo.calendars.Year AS varchar(20))+'-'+RIGHT('0'+cast(dbo.calendars.Month AS varchar(20)),2)+'-'+RIGHT('0'+cast(dbo.calendars.Date AS varchar(20)),2)) AS combined_date,dbo.calendars.Week,dbo.calendars.status,dbo.calendars.Date, dbo.calendars.Month, dbo.calendars.Year
FROM     dbo.timetables INNER JOIN
                  dbo.calendars ON dbo.calendars.Day = dbo.timetables.day
WHERE  (dbo.calendars.status = 'CANCELLATION') OR
                  (dbo.calendars.status = 'HOLIDAY') AND (dbo.timetables.fromTime >= dbo.calendars.FromTime) AND (dbo.timetables.toTime <= dbo.calendars.ToTime) AND (dbo.timetables.course IS NOT NULL)

go

