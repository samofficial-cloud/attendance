

CREATE PROCEDURE [dbo].[getAllCoursesAndLectures_noAllStudents]
	@course varchar(100)
	
AS
BEGIN
	
	select dbo.attendance.reg_no,courses.lectures_no FROM dbo.attendance INNER JOIN dbo.courses ON dbo.attendance.courseId=dbo.courses.course WHERE dbo.attendance.courseId like  '%'+@course+'%'      AND dbo.attendance.title='student' AND dbo.attendance.validity='VALID' AND dbo.attendance.status=1 AND dbo.attendance.category='CLASS' GROUP BY dbo.attendance.reg_no,dbo.courses.lectures_no
    
END
go

