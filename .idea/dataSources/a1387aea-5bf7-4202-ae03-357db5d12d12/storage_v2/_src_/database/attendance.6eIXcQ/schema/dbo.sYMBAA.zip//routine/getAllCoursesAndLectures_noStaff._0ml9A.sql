

CREATE PROCEDURE [dbo].[getAllCoursesAndLectures_noStaff]
	@reg_no varchar(100)
	
AS
BEGIN
	
	select dbo.attendance.courseId,courses.lectures_no FROM dbo.attendance INNER JOIN dbo.courses ON dbo.attendance.courseId=dbo.courses.course WHERE dbo.attendance.reg_no=@reg_no AND dbo.attendance.title='staff' AND dbo.attendance.validity='VALID' AND dbo.attendance.status=1 AND dbo.attendance.category='CLASS' GROUP BY dbo.attendance.courseId,dbo.courses.lectures_no
    
END
go

