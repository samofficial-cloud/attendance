
CREATE PROCEDURE [dbo].[getAttendanceAll] 
	@course varchar(100),
	@reg_no varchar(100),
	@lectures_no int,
	@today varchar(100),
	@semday1 varchar(100)

AS
BEGIN
	
	Declare @extra_C int
	Declare @extra_H int

	Select @extra_C= Count(*) from( select combined_date  from dbo.combine_holidays WHERE date BETWEEN @semday1 AND @today AND course like '%'+@course+'%' AND status='CANCELLATION' GROUP BY combined_date) AS test

	Select @extra_H= Count(*) from( select combined_date  from dbo.combine_holidays WHERE date BETWEEN @semday1 AND @today AND course like '%'+@course+'%' AND status='HOLIDAY' GROUP BY combined_date) AS test


	SELECT name,reg_no,CONVERT(DECIMAL(20,2),CONVERT(DECIMAL(20,2),(COUNT(status)+@extra_C+@extra_H))*CONVERT(DECIMAL(20,2),CONVERT(DECIMAL(20,2),100)/CONVERT(DECIMAL(20,2),@lectures_no))) AS PERCENTAGE FROM dbo.attendance WHERE courseId like  '%'+@course+'%' AND validity='VALID' AND status=1 AND reg_no=@reg_no AND title='student' AND category='CLASS' GROUP BY name,reg_no 
    
END
go

