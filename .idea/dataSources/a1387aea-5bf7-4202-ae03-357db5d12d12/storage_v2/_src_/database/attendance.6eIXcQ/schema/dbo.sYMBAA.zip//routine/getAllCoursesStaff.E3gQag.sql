

CREATE PROCEDURE [dbo].[getAllCoursesStaff] 
    @reg_no varchar(100),
	@course varchar(100),
	@lectures_no int,
	@today varchar(100),
	@semday1 varchar(100)
AS
BEGIN
	Declare @name varchar(100)
	
	SELECT @name= NAME FROM dbo.USERINFO WHERE SSN=@reg_no 

	Declare @extra_C int
	Declare @extra_H int

	Select @extra_C= Count(*) from( select combined_date  from dbo.combine_holidays WHERE date BETWEEN @semday1 AND @today AND course like '%'+@course+'%' AND status='CANCELLATION' GROUP BY combined_date) AS test

	Select @extra_H= Count(*) from( select combined_date  from dbo.combine_holidays WHERE date BETWEEN @semday1 AND @today AND course like '%'+@course+'%' AND status='HOLIDAY' GROUP BY combined_date) AS test


	IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@course+'%' AND technical_staff like '%'+@name+'%'), 0))=1
	BEGIN
		SELECT dbo.attendance.courseId,CONVERT(DECIMAL(20,2),CONVERT(DECIMAL(20,2),COUNT(dbo.attendance.status)+@extra_C+@extra_H)*CONVERT(DECIMAL(20,2),CONVERT(DECIMAL(20,2),100)/CONVERT(DECIMAL(20,2),@lectures_no))) AS PERCENTAGE,dbo.lecturers.course_name FROM dbo.attendance INNER JOIN dbo.lecturers ON dbo.attendance.courseId=dbo.lecturers.course WHERE dbo.lecturers.course like  '%'+@course+'%' AND dbo.attendance.validity='VALID' AND dbo.attendance.status=1 AND dbo.attendance.reg_no=@reg_no AND dbo.attendance.title='staff' AND dbo.attendance.category='CLASS' AND dbo.lecturers.technical_staff like '%'+@name+'%'  GROUP BY dbo.attendance.courseId,dbo.lecturers.course_name
    END

	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@course+'%'AND instructor like '%'+@name+'%'), 0))=1 
	BEGIN
	
	SELECT dbo.attendance.courseId,CONVERT(DECIMAL(20,2),CONVERT(DECIMAL(20,2),COUNT(dbo.attendance.status)+@extra_C+@extra_H)*CONVERT(DECIMAL(20,2),CONVERT(DECIMAL(20,2),100)/CONVERT(DECIMAL(20,2),@lectures_no))) AS PERCENTAGE,dbo.lecturers.course_name FROM dbo.attendance INNER JOIN dbo.lecturers ON dbo.attendance.courseId=dbo.lecturers.course WHERE dbo.lecturers.course like  '%'+@course+'%' AND dbo.attendance.validity='VALID' AND dbo.attendance.status=1 AND dbo.attendance.reg_no=@reg_no AND dbo.attendance.title='staff' AND dbo.attendance.category='CLASS' AND dbo.lecturers.instructor like '%'+@name+'%' GROUP BY dbo.attendance.courseId,dbo.lecturers.course_name

	END

	ELSE 
	BEGIN
	
	SELECT dbo.attendance.courseId,CONVERT(DECIMAL(20,2),CONVERT(DECIMAL(20,2),COUNT(dbo.attendance.status)+@extra_C+@extra_H)*CONVERT(DECIMAL(20,2),CONVERT(DECIMAL(20,2),100)/CONVERT(DECIMAL(20,2),@lectures_no))) AS PERCENTAGE,dbo.lecturers.course_name FROM dbo.attendance INNER JOIN dbo.lecturers ON dbo.attendance.courseId=dbo.lecturers.course WHERE dbo.attendance.courseId like  '%'+@course+'%' AND dbo.attendance.validity='NON EXISTING' AND dbo.attendance.reg_no=@reg_no AND dbo.attendance.title='staff' AND dbo.attendance.category='CLIENT' AND dbo.lecturers.instructor=@name GROUP BY dbo.attendance.courseId,dbo.lecturers.course_name
	END
END
go

