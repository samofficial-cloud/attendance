
CREATE PROCEDURE [dbo].[getAllCoursesTest1]
	@reg_no varchar(100)
	
AS
BEGIN
	Declare @program varchar(100)
	SELECT @program= dbo.DEPARTMENTS.DEPTNAME from dbo.USERINFO INNER JOIN dbo.DEPARTMENTS ON dbo.USERINFO.DEFAULTDEPTID=dbo.DEPARTMENTS.DEPTID WHERE dbo.USERINFO.SSN=@reg_no GROUP BY dbo.DEPARTMENTS.DEPTNAME
	SELECT dbo.attendance.courseId,dbo.attendance.datetime,dbo.courses.course_name FROM dbo.attendance INNER JOIN dbo.courses  ON dbo.attendance.courseId=dbo.courses.course WHERE dbo.attendance.validity='VALID' AND dbo.attendance.reg_no=@reg_no AND dbo.attendance.title='student' AND dbo.attendance.category='TEST' AND dbo.attendance.test_type='Test 1' AND dbo.courses.program=@program GROUP BY dbo.attendance.courseId,dbo.attendance.datetime,dbo.courses.course_name
    
END
go

