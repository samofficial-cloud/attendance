CREATE TRIGGER [dbo].[trg_to_get_attendance]
ON [dbo].[CHECKINOUT]
AFTER INSERT
AS
BEGIN

Declare @id int
Declare @day varchar(50)
Declare @programme varchar(50)
Declare @position varchar(50)
Declare @venue varchar(50)
Declare @sn varchar(50)
Declare @courseId varchar(50)
Declare @courseId_first_to varchar(50)
Declare @courseId_second_to varchar(50)
Declare @courseId_third_to varchar(50)
Declare @courseId_fourth_to varchar(50)
Declare @validity varchar(50)
Declare @courseTimeFrom time
Declare @courseTimeTo time
Declare @time varchar(50)
Declare @dayfinal varchar(50)
Declare @date varchar(50)
Declare @month_no varchar(50)
Declare @day_no varchar(50)
Declare @year_no varchar(50)
Declare @week_no varchar(50)
Declare @reg_no varchar(50)
Declare @name varchar(50)
Declare @title varchar(50)
select @id= USERID from inserted
select @day= CHECKTIME from inserted
select @sn= sn from inserted
select @dayfinal= DATENAME(weekday,@day)
select @date= CONVERT(date,@day)
select @reg_no= SSN from dbo.USERINFO WHERE USERID=@id
select @name= NAME from dbo.USERINFO WHERE USERID=@id
select @title= TITLE from dbo.USERINFO WHERE USERID=@id
select @time=cast(CHECKTIME as time) from inserted
select @programme= dbo.DEPARTMENTS.DEPTNAME FROM dbo.DEPARTMENTS INNER JOIN dbo.USERINFO ON dbo.DEPARTMENTS.DEPTID=dbo.USERINFO.DEFAULTDEPTID WHERE dbo.USERINFO.USERID=@id
select @venue= dbo.Machines.MachineAlias FROM dbo.Machines INNER JOIN dbo.CHECKINOUT ON dbo.Machines.sn=dbo.CHECKINOUT.sn WHERE dbo.CHECKINOUT.sn=@sn
Declare @type varchar(50)
select @month_no=Cast(DATEPART(month,@day) as varchar(50))
select @day_no=Cast(DATEPART(day,@day) as varchar(50))
select @year_no=Cast(DATEPART(year,@day) as varchar(50))
select @week_no= Week from dbo.calendars WHERE Date=@day_no AND Month=@month_no  AND Year=@year_no 


/*TESTS */
IF (SELECT ISNULL((select 1 from dbo.tests  WHERE [date]=@date AND fromTime<=@time AND toTime>=@time AND venue like '%'+@venue+'%'), 0))=1
BEGIN
   select @courseId= course from dbo.tests  WHERE [date]=@date AND fromTime<=@time AND toTime>=@time AND venue like '%'+@venue+'%'
   select @courseTimeFrom= fromTime from dbo.tests  WHERE [date]=@date AND fromTime<=@time AND toTime>=@time AND venue like '%'+@venue+'%'
   select @courseTimeTo= toTime from dbo.tests  WHERE [date]=@date AND fromTime<=@time AND toTime>=@time AND venue like '%'+@venue+'%'


   select @validity= CASE 
					WHEN DATEDIFF(minute, fromTime, @time)<=30 THEN 'VALID'
					ELSE 'INVALID'
					END
				
					from dbo.tests  WHERE [date]=@date AND fromTime<=@time AND toTime>=@time AND venue like '%'+@venue+'%' GROUP BY fromTime

select @type=type from dbo.tests  WHERE [date]=@date AND fromTime<=@time AND toTime>=@time AND venue like '%'+@venue+'%'


/*CODE FOR POSITION STARTS*/


IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%' AND technical_staff like '%'+@name+'%'), 0))=1
	BEGIN
	
	set @position='TECH'

    END

	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND Technical_Staff_2 like '%'+@name+'%'), 0))=1 
	BEGIN
	
	set @position='TECH'
	END


	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND Technical_Staff_3 like '%'+@name+'%'), 0))=1 
	BEGIN
	
set @position='TECH'
	END



	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND instructor like '%'+@name+'%'), 0))=1 
	BEGIN
	
	set @position='LECTURER'
	END


	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND Instructor_2 like '%'+@name+'%'), 0))=1 
	BEGIN
	
	set @position='LECTURER'
	END


	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND Instructor_3 like '%'+@name+'%'), 0))=1 
	BEGIN
	
	set @position='LECTURER'
	END


ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND Instructor_4 like '%'+@name+'%'), 0))=1 
	BEGIN
	
	set @position='LECTURER'
	END


	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND Instructor_5 like '%'+@name+'%'), 0))=1 
	BEGIN
	
	set @position='LECTURER'
	END

	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND Tutorial_Assistant like '%'+@name+'%'), 0))=1 
	BEGIN
	
	set @position='TUT'
	END
	
	ELSE
BEGIN
Update dbo.system_errors
set [status]='in Test ERROR0', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))
END


/*CODE FOR POSITION ENDS*/



/*insert into dbo.attendance
values (Cast(@name as varchar(50)),Cast(@reg_no as varchar(50)),Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,Cast(@day as varchar(50)),Cast(@title as varchar(50)),Cast(@programme as varchar(100)),'1',Cast(@validity as varchar(50)),'TEST',Cast(@date as varchar(50)),Cast(@type as varchar(50)))*/

/*NEW CODE STARTS*/


IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG' AND date=@date), 0))=1
BEGIN
UPDATE dbo.attendance
SET  courseTimeFrom=@courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='TEST',date=Cast(@date as varchar(50)),test_type=@type
WHERE reg_no=@reg_no AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date
END 

/* Check for staff TECH its dummy*/
ELSE IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG STAFF TECH' AND program='DUMMY STAFF DEPT' AND date=@date), 0))=1

BEGIN
UPDATE dbo.attendance
SET name=@name, reg_no=@reg_no ,courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),test_type=@type,position=@position
WHERE name like '%'+@name+'%' AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date
END

ELSE IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG STAFF TECH2' AND program='DUMMY STAFF DEPT' AND date=@date), 0))=1

BEGIN
UPDATE dbo.attendance
SET name=@name, reg_no=@reg_no ,courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),test_type=@type,position=@position
WHERE name like '%'+@name+'%' AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date
END

ELSE IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG STAFF TECH3' AND program='DUMMY STAFF DEPT' AND date=@date), 0))=1

BEGIN
UPDATE dbo.attendance
SET name=@name, reg_no=@reg_no ,courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),test_type=@type,position=@position
WHERE name like '%'+@name+'%' AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date
END

 
 /* Check for Tutorial assistant*/
ELSE IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG STAFF TUT' AND program='DUMMY STAFF DEPT' AND date=@date), 0))=1

BEGIN
UPDATE dbo.attendance
SET name=@name, reg_no=@reg_no,courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),test_type=@type,position=@position
WHERE name like '%'+@name+'%' AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date 
END


/* Check for staff*/

ELSE IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG STAFF' AND program='DUMMY STAFF DEPT' AND date=@date), 0))=1

BEGIN
UPDATE dbo.attendance
SET name=@name, reg_no=@reg_no,courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),test_type=@type,position=@position
WHERE name like '%'+@name+'%' AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date
END

ELSE IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG STAFF2' AND program='DUMMY STAFF DEPT' AND date=@date), 0))=1

BEGIN
UPDATE dbo.attendance
SET name=@name, reg_no=@reg_no,courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),test_type=@type,position=@position
WHERE name like '%'+@name+'%' AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date
END

ELSE IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG STAFF3' AND program='DUMMY STAFF DEPT' AND date=@date), 0))=1

BEGIN
UPDATE dbo.attendance
SET name=@name, reg_no=@reg_no,courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),test_type=@type,position=@position
WHERE name like '%'+@name+'%' AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date
END

ELSE IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG STAFF4' AND program='DUMMY STAFF DEPT' AND date=@date), 0))=1

BEGIN
UPDATE dbo.attendance
SET name=@name, reg_no=@reg_no,courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),test_type=@type,position=@position
WHERE name like '%'+@name+'%' AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date
END

ELSE IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG STAFF5' AND program='DUMMY STAFF DEPT' AND date=@date), 0))=1

BEGIN
UPDATE dbo.attendance
SET name=@name, reg_no=@reg_no,courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),test_type=@type,position=@position
WHERE name like '%'+@name+'%' AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date
END


ELSE
BEGIN
/*DUMMY FILLING*/
/*CHECKS IF STUDENT BELONGS TO THE COURSE*/
IF (SELECT ISNULL((select 1 from dbo.USERINFO INNER JOIN dbo.DEPARTMENTS ON dbo.USERINFO.DEFAULTDEPTID=dbo.DEPARTMENTS.DEPTID INNER JOIN dbo.courses ON dbo.courses.program=dbo.DEPARTMENTS.DEPTNAME WHERE dbo.courses.course=@courseId AND dbo.USERINFO.NAME=@name AND dbo.courses.program=@programme), 0))=1
BEGIN
insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME','DUMMY TITLE',Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'TEST',Cast(@date as varchar(50)),@type,'MIMI')

/*Student also fills dummy for staff*/
/*Check whether they exist first*/

IF (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.tests ON dbo.lecturers.course=dbo.tests.course WHERE dbo.lecturers.course like '%'+@courseId+'%' AND dbo.lecturers.instructor IS NOT NULL AND dbo.tests.date=@date AND dbo.tests.fromTime<=@time AND dbo.tests.toTime>=@time AND dbo.tests.venue like '%'+@venue+'%'), 0))=1
	BEGIN
		insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'TEST',Cast(@date as varchar(50)),'NULL','MIMI')

	END

ELSE
BEGIN
Update dbo.system_errors
set [status]='in Test ERROR1', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))
END


IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.tests ON dbo.lecturers.course=dbo.tests.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.Instructor_2 IS NOT NULL AND dbo.tests.date=@date AND dbo.tests.fromTime<=@time AND dbo.tests.toTime>=@time AND dbo.tests.venue like '%'+@venue+'%'), 0))=1 
	BEGIN

	insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF2',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'TEST',Cast(@date as varchar(50)),'NULL','MIMI')
   
END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in Test ERROR2', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.tests ON dbo.lecturers.course=dbo.tests.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.Instructor_3 IS NOT NULL AND dbo.tests.date=@date AND dbo.tests.fromTime<=@time AND dbo.tests.toTime>=@time AND dbo.tests.venue like '%'+@venue+'%'), 0))=1 
	BEGIN

	insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF3',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'TEST',Cast(@date as varchar(50)),'NULL','MIMI')
   
END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in Test ERROR3', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.tests ON dbo.lecturers.course=dbo.tests.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.Instructor_4 IS NOT NULL AND dbo.tests.date=@date AND dbo.tests.fromTime<=@time AND dbo.tests.toTime>=@time AND dbo.tests.venue like '%'+@venue+'%'), 0))=1 
	BEGIN

	insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF4',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'TEST',Cast(@date as varchar(50)),@type,'MIMI')
   
END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in Test ERROR4', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.tests ON dbo.lecturers.course=dbo.tests.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.Instructor_5 IS NOT NULL AND dbo.tests.date=@date AND dbo.tests.fromTime<=@time AND dbo.tests.toTime>=@time AND dbo.tests.venue like '%'+@venue+'%'), 0))=1 
	BEGIN

	insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF5',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'TEST',Cast(@date as varchar(50)),'NULL','MIMI')
   
END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in Test ERROR5', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END

IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.tests ON dbo.lecturers.course=dbo.tests.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.Tutorial_Assistant IS NOT NULL AND dbo.tests.date=@date AND dbo.tests.fromTime<=@time AND dbo.tests.toTime>=@time AND dbo.tests.venue like '%'+@venue+'%' AND dbo.tests.name='TEST'), 0))=1 
	BEGIN

	insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF TUT',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')
   
END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in Test ERROR6', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.tests ON dbo.lecturers.course=dbo.tests.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.technical_staff IS NOT NULL AND dbo.tests.date=@date AND dbo.tests.fromTime<=@time AND dbo.tests.toTime>=@time AND dbo.tests.venue like '%'+@venue+'%' AND dbo.tests.name='TEST'), 0))=1 
	BEGIN

	insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF TECH',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')
   
END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in Test ERROR7', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.tests ON dbo.lecturers.course=dbo.tests.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.Technical_Staff_2 IS NOT NULL AND dbo.tests.date=@date AND dbo.tests.fromTime<=@time AND dbo.tests.toTime>=@time AND dbo.tests.venue like '%'+@venue+'%' AND dbo.tests.name='TEST'), 0))=1 
	BEGIN

	insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF TECH2',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')
   
END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in Test ERROR8', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.tests ON dbo.lecturers.course=dbo.tests.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.Technical_Staff_3 IS NOT NULL AND dbo.tests.date=@date AND dbo.tests.fromTime<=@time AND dbo.tests.toTime>=@time AND dbo.tests.venue like '%'+@venue+'%' AND dbo.tests.name='TEST'), 0))=1 
	BEGIN
	insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF TECH3',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')
   
END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in Test ERROR9', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


END


ELSE

BEGIN
Update dbo.system_errors
set [status]='in Test ERROR10', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END

/*Dummy filling for staff BY themselves*/

IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%' AND technical_staff like '%'+@name+'%'), 0))=1
	BEGIN
		insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF TECH',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

/*Dummy filling for students BY staff*/
insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME','DUMMY TITLE',Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')


    END


	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND Technical_Staff_2 like '%'+@name+'%'), 0))=1 
	BEGIN
	
			insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF TECH2',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

/*Dummy filling for students BY staff*/
insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME','DUMMY TITLE',Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

	END


	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND Technical_Staff_3 like '%'+@name+'%'), 0))=1 
	BEGIN
	
			insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF TECH3',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

/*Dummy filling for students BY staff*/
insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME','DUMMY TITLE',Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

	END



	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND instructor like '%'+@name+'%'), 0))=1 
	BEGIN
	
			insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

/*Dummy filling for students BY staff*/
insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME','DUMMY TITLE',Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

	END


	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND Instructor_2 like '%'+@name+'%'), 0))=1 
	BEGIN
	
			insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF2',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

/*Dummy filling for students BY staff*/
insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME','DUMMY TITLE',Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

	END


	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND Instructor_3 like '%'+@name+'%'), 0))=1 
	BEGIN
	
			insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF3',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

/*Dummy filling for students BY staff*/
insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME','DUMMY TITLE',Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

	END


ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND Instructor_4 like '%'+@name+'%'), 0))=1 
	BEGIN
	
			insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF4',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

/*Dummy filling for students BY staff*/
insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME','DUMMY TITLE',Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

	END


	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND Instructor_5 like '%'+@name+'%'), 0))=1 
	BEGIN
	
			insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF5',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

/*Dummy filling for students BY staff*/
insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME','DUMMY TITLE',Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

	END


	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND Tutorial_Assistant like '%'+@name+'%'), 0))=1 
	BEGIN
	
			insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF TUT',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

/*Dummy filling for students BY staff*/
insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME','DUMMY TITLE',Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

	END


ELSE

BEGIN
Update dbo.system_errors
set [status]='in Test ERROR11', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END

/*partial complete data filling for students by themselves*/
/*Check first if the student belongs to the course*/
IF (SELECT ISNULL((select 1 from dbo.USERINFO INNER JOIN dbo.DEPARTMENTS ON dbo.USERINFO.DEFAULTDEPTID=dbo.DEPARTMENTS.DEPTID INNER JOIN dbo.courses ON dbo.courses.program=dbo.DEPARTMENTS.DEPTNAME WHERE dbo.courses.course=@courseId AND dbo.USERINFO.NAME=@name AND dbo.courses.program=@programme), 0))=1
BEGIN
insert into dbo.attendance
SELECT dbo.USERINFO.NAME,dbo.USERINFO.SSN,dbo.courses.course,@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.USERINFO INNER JOIN dbo.DEPARTMENTS ON dbo.USERINFO.DEFAULTDEPTID=dbo.DEPARTMENTS.DEPTID INNER JOIN dbo.courses ON dbo.courses.program=dbo.DEPARTMENTS.DEPTNAME WHERE dbo.courses.course=@courseId 

UPDATE attendance
SET  courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='TEST',date=Cast(@date as varchar(50)),test_type=@type
WHERE reg_no=@reg_no AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date AND program=@programme
END 

ELSE
BEGIN

Update dbo.system_errors
set [status]='in Test ERROR11b', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END



/*Partial complete data filling for staff by students*/



/*Check if the person associates with the course */
/*If the person is a student*/
IF (SELECT ISNULL((select 1 from dbo.USERINFO INNER JOIN dbo.DEPARTMENTS ON dbo.USERINFO.DEFAULTDEPTID=dbo.DEPARTMENTS.DEPTID INNER JOIN dbo.courses ON dbo.courses.program=dbo.DEPARTMENTS.DEPTNAME WHERE dbo.courses.course=@courseId AND dbo.USERINFO.NAME=@name AND dbo.courses.program=@programme), 0))=1
BEGIN
 
/*CODE STARTS*/



IF (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.tests ON dbo.lecturers.course=dbo.tests.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.instructor IS NOT NULL AND dbo.tests.date=@date AND dbo.tests.fromTime<=@time AND dbo.tests.toTime>=@time AND dbo.tests.venue like '%'+@venue+'%'), 0))=1
	BEGIN
Insert into dbo.attendance
SELECT instructor,'STAFF partial reg',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.lecturers WHERE course like '%'+@courseId+'%'

	END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in Test ERROR12', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.tests ON dbo.lecturers.course=dbo.tests.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.Instructor_2 IS NOT NULL AND dbo.tests.date=@date AND dbo.tests.fromTime<=@time AND dbo.tests.toTime>=@time AND dbo.tests.venue like '%'+@venue+'%'), 0))=1 
	BEGIN

Insert into dbo.attendance
SELECT Instructor_2,'STAFF2 partial reg',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.lecturers WHERE course like '%'+@courseId+'%'
END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in Test ERROR13', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.tests ON dbo.lecturers.course=dbo.tests.course WHERE dbo.lecturers.course like '%'+@courseId+'%' AND dbo.lecturers.Instructor_3 IS NOT NULL AND dbo.tests.date=@date AND dbo.tests.fromTime<=@time AND dbo.tests.toTime>=@time AND dbo.tests.venue like '%'+@venue+'%'), 0))=1 
	BEGIN

Insert into dbo.attendance
SELECT Instructor_3,'STAFF3 partial reg',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.lecturers WHERE course like '%'+@courseId+'%'
END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in Test ERROR14', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.tests ON dbo.lecturers.course=dbo.tests.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.Instructor_4 IS NOT NULL AND dbo.tests.date=@date AND dbo.tests.fromTime<=@time AND dbo.tests.toTime>=@time AND dbo.tests.venue like '%'+@venue+'%'), 0))=1 
	BEGIN

Insert into dbo.attendance
SELECT Instructor_4,'STAFF4 partial reg',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.lecturers WHERE course like '%'+@courseId+'%'
END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in Test ERROR15', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.tests ON dbo.lecturers.course=dbo.tests.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.Instructor_5 IS NOT NULL AND dbo.tests.date=@date AND dbo.tests.fromTime<=@time AND dbo.tests.toTime>=@time AND dbo.tests.venue like '%'+@venue+'%'), 0))=1 
	BEGIN

Insert into dbo.attendance
SELECT Instructor_5,'STAFF5 partial reg',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.lecturers WHERE course like '%'+@courseId+'%' 
END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in Test ERROR16', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END

IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.tests ON dbo.lecturers.course=dbo.tests.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.Tutorial_Assistant IS NOT NULL AND dbo.tests.date=@date AND dbo.tests.fromTime<=@time AND dbo.tests.toTime>=@time AND dbo.tests.venue like '%'+@venue+'%' AND dbo.tests.name='test'), 0))=1 
	BEGIN

Insert into dbo.attendance
SELECT Tutorial_Assistant,'STAFF TUT partial reg',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.lecturers WHERE course like '%'+@courseId+'%'  
END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in Test ERROR17', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.tests ON dbo.lecturers.course=dbo.tests.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.technical_staff IS NOT NULL AND dbo.tests.date=@date AND dbo.tests.fromTime<=@time AND dbo.tests.toTime>=@time AND dbo.tests.venue like '%'+@venue+'%' AND dbo.tests.name='test'), 0))=1 
	BEGIN

Insert into dbo.attendance
SELECT technical_staff,'TECH STAFF partial reg',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.lecturers WHERE course like '%'+@courseId+'%'

END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in Test ERROR18', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.tests ON dbo.lecturers.course=dbo.tests.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.Technical_Staff_2 IS NOT NULL AND dbo.tests.date=@date AND dbo.tests.fromTime<=@time AND dbo.tests.toTime>=@time AND dbo.tests.venue like '%'+@venue+'%' AND dbo.tests.name='test'), 0))=1 
	BEGIN

Insert into dbo.attendance
SELECT Technical_Staff_2,'TECH2 STAFF partial reg',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.lecturers WHERE course like '%'+@courseId+'%'

END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in Test ERROR19', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.tests ON dbo.lecturers.course=dbo.tests.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.Technical_Staff_3 IS NOT NULL AND dbo.tests.date=@date AND dbo.tests.fromTime<=@time AND dbo.tests.toTime>=@time AND dbo.tests.venue like '%'+@venue+'%' AND dbo.tests.name='test'), 0))=1 
	BEGIN
Insert into dbo.attendance
SELECT technical_staff_3,'TECH3 STAFF partial reg',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.lecturers WHERE course like '%'+@courseId+'%'
  
END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in Test ERROR20', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


/*CODE ENDS*/

 

END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in Test ERROR21', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


/*Partial complete data filling for staff by themselves*/


IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%' AND technical_staff like '%'+@name+'%'), 0))=1
	BEGIN
		insert into dbo.attendance
values (Cast(@name as varchar(50)),Cast(@reg_no as varchar(50)),Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL',Cast(@title as varchar(50)),Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

UPDATE dbo.attendance
SET courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),position=@position
WHERE reg_no=@reg_no AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date AND program=@programme

/*Partial complete data filling for students by staff*/
/*Check if there was any student who signed in b4*/
IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG' AND date=@date), 0))=1
BEGIN
insert into dbo.attendance
SELECT dbo.USERINFO.NAME,dbo.USERINFO.SSN,dbo.courses.course,@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.USERINFO INNER JOIN dbo.DEPARTMENTS ON dbo.USERINFO.DEFAULTDEPTID=dbo.DEPARTMENTS.DEPTID INNER JOIN dbo.courses ON dbo.courses.program=dbo.DEPARTMENTS.DEPTNAME WHERE dbo.courses.course=@courseId

END 

ELSE

	BEGIN

	Update dbo.system_errors
set [status]='in Test ERROR22', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))


	END


    END


	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%' AND Technical_Staff_2 like '%'+@name+'%'), 0))=1 
	BEGIN
	
		insert into dbo.attendance
values (Cast(@name as varchar(50)),Cast(@reg_no as varchar(50)),Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL',Cast(@title as varchar(50)),Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')


UPDATE dbo.attendance
SET courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),position=@position
WHERE reg_no=@reg_no AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date AND program=@programme

/*Partial complete data filling for students by staff*/
/*Check if there was any student who signed in b4*/
IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG' AND date=@date), 0))=1
BEGIN
insert into dbo.attendance
SELECT dbo.USERINFO.NAME,dbo.USERINFO.SSN,dbo.courses.course,@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.USERINFO INNER JOIN dbo.DEPARTMENTS ON dbo.USERINFO.DEFAULTDEPTID=dbo.DEPARTMENTS.DEPTID INNER JOIN dbo.courses ON dbo.courses.program=dbo.DEPARTMENTS.DEPTNAME WHERE dbo.courses.course=@courseId

END 

ELSE

	BEGIN

	Update dbo.system_errors
set [status]='in Test ERROR23', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))


	END


	END



	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%' AND Technical_Staff_3 like '%'+@name+'%'), 0))=1 
	BEGIN
	
		insert into dbo.attendance
values (Cast(@name as varchar(50)),Cast(@reg_no as varchar(50)),Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL',Cast(@title as varchar(50)),Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')


UPDATE dbo.attendance
SET courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),position=@position
WHERE reg_no=@reg_no AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date AND program=@programme

/*Partial complete data filling for students by staff*/
/*Check if there was any student who signed in b4*/
IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG' AND date=@date), 0))=1
BEGIN
insert into dbo.attendance
SELECT dbo.USERINFO.NAME,dbo.USERINFO.SSN,dbo.courses.course,@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.USERINFO INNER JOIN dbo.DEPARTMENTS ON dbo.USERINFO.DEFAULTDEPTID=dbo.DEPARTMENTS.DEPTID INNER JOIN dbo.courses ON dbo.courses.program=dbo.DEPARTMENTS.DEPTNAME WHERE dbo.courses.course=@courseId

END 

ELSE

	BEGIN

	Update dbo.system_errors
set [status]='in Test ERROR24', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))


	END


	END


	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%' AND instructor like '%'+@name+'%'), 0))=1 
	BEGIN
	
		insert into dbo.attendance
values (Cast(@name as varchar(50)),Cast(@reg_no as varchar(50)),Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL',Cast(@title as varchar(50)),Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')


UPDATE dbo.attendance
SET courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),position=@position
WHERE reg_no=@reg_no AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date AND program=@programme

/*Partial complete data filling for students by staff*/
/*Check if there was any student who signed in b4*/
IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG' AND date=@date), 0))=1
BEGIN
insert into dbo.attendance
SELECT dbo.USERINFO.NAME,dbo.USERINFO.SSN,dbo.courses.course,@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.USERINFO INNER JOIN dbo.DEPARTMENTS ON dbo.USERINFO.DEFAULTDEPTID=dbo.DEPARTMENTS.DEPTID INNER JOIN dbo.courses ON dbo.courses.program=dbo.DEPARTMENTS.DEPTNAME WHERE dbo.courses.course=@courseId

END 

ELSE

	BEGIN

	Update dbo.system_errors
set [status]='in Test ERROR25', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))


	END


	END


		ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%' AND Instructor_2 like '%'+@name+'%'), 0))=1 
	BEGIN
	
		insert into dbo.attendance
values (Cast(@name as varchar(50)),Cast(@reg_no as varchar(50)),Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL',Cast(@title as varchar(50)),Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')


UPDATE dbo.attendance
SET courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),position=@position
WHERE reg_no=@reg_no AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date AND program=@programme

/*Partial complete data filling for students by staff*/
/*Check if there was any student who signed in b4*/
IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG' AND date=@date), 0))=1
BEGIN
insert into dbo.attendance
SELECT dbo.USERINFO.NAME,dbo.USERINFO.SSN,dbo.courses.course,@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.USERINFO INNER JOIN dbo.DEPARTMENTS ON dbo.USERINFO.DEFAULTDEPTID=dbo.DEPARTMENTS.DEPTID INNER JOIN dbo.courses ON dbo.courses.program=dbo.DEPARTMENTS.DEPTNAME WHERE dbo.courses.course=@courseId

END 

ELSE

	BEGIN

	Update dbo.system_errors
set [status]='in Test ERROR26', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))


	END


	END


		ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%' AND Instructor_3 like '%'+@name+'%'), 0))=1 
	BEGIN
	
		insert into dbo.attendance
values (Cast(@name as varchar(50)),Cast(@reg_no as varchar(50)),Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL',Cast(@title as varchar(50)),Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')


UPDATE dbo.attendance
SET courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),position=@position
WHERE reg_no=@reg_no AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date AND program=@programme

/*Partial complete data filling for students by staff*/
/*Check if there was any student who signed in b4*/
IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG' AND date=@date), 0))=1
BEGIN
insert into dbo.attendance
SELECT dbo.USERINFO.NAME,dbo.USERINFO.SSN,dbo.courses.course,@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.USERINFO INNER JOIN dbo.DEPARTMENTS ON dbo.USERINFO.DEFAULTDEPTID=dbo.DEPARTMENTS.DEPTID INNER JOIN dbo.courses ON dbo.courses.program=dbo.DEPARTMENTS.DEPTNAME WHERE dbo.courses.course=@courseId

END 

ELSE

	BEGIN

	Update dbo.system_errors
set [status]='in Test ERROR27', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))


	END


	END



		ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%' AND Instructor_4 like '%'+@name+'%'), 0))=1 
	BEGIN
	
		insert into dbo.attendance
values (Cast(@name as varchar(50)),Cast(@reg_no as varchar(50)),Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL',Cast(@title as varchar(50)),Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')


UPDATE dbo.attendance
SET courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),position=@position
WHERE reg_no=@reg_no AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date AND program=@programme

/*Partial complete data filling for students by staff*/
/*Check if there was any student who signed in b4*/
IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG' AND date=@date), 0))=1
BEGIN
insert into dbo.attendance
SELECT dbo.USERINFO.NAME,dbo.USERINFO.SSN,dbo.courses.course,@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.USERINFO INNER JOIN dbo.DEPARTMENTS ON dbo.USERINFO.DEFAULTDEPTID=dbo.DEPARTMENTS.DEPTID INNER JOIN dbo.courses ON dbo.courses.program=dbo.DEPARTMENTS.DEPTNAME WHERE dbo.courses.course=@courseId

END 

ELSE

	BEGIN

Update dbo.system_errors
set [status]='in Test ERROR28', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))


	END


	END


		ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%' AND Instructor_5 like '%'+@name+'%'), 0))=1 
	BEGIN
	
		insert into dbo.attendance
values (Cast(@name as varchar(50)),Cast(@reg_no as varchar(50)),Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL',Cast(@title as varchar(50)),Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')


UPDATE dbo.attendance
SET courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),position=@position
WHERE reg_no=@reg_no AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date AND program=@programme

/*Partial complete data filling for students by staff*/
/*Check if there was any student who signed in b4*/
IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG' AND date=@date), 0))=1
BEGIN
insert into dbo.attendance
SELECT dbo.USERINFO.NAME,dbo.USERINFO.SSN,dbo.courses.course,@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.USERINFO INNER JOIN dbo.DEPARTMENTS ON dbo.USERINFO.DEFAULTDEPTID=dbo.DEPARTMENTS.DEPTID INNER JOIN dbo.courses ON dbo.courses.program=dbo.DEPARTMENTS.DEPTNAME WHERE dbo.courses.course=@courseId

END 

ELSE

	BEGIN

	Update dbo.system_errors
set [status]='in Test ERROR29', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))


	END


	END



ELSE

BEGIN
Update dbo.system_errors
set [status]='in Test ERROR30', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


/*insert into dbo.attendance
values (Cast(@name as varchar(50)),Cast(@reg_no as varchar(50)),Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,Cast(@day as varchar(50)),Cast(@title as varchar(50)),Cast(@programme as varchar(100)),'1',Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')*/

END







/*NEW CODE ENDS */

END

/*UE */
ELSE IF (SELECT ISNULL((select 1 from dbo.exams inner join dbo.courses on  dbo.exams.course  like '%'+dbo.courses.course+'%' where dbo.courses.program=@programme AND dbo.exams.day=@dayfinal AND dbo.exams.fromTime<=@time AND dbo.exams.toTime>=@time AND dbo.exams.venue=@venue and dbo.exams.Week=Cast(@week_no as varchar(50))), 0))=1
BEGIN
   select @courseId= dbo.courses.course
			from dbo.exams inner join dbo.courses on  dbo.exams.course  like '%'+dbo.courses.course+'%' where dbo.courses.program=@programme AND dbo.exams.day=@dayfinal AND dbo.exams.fromTime<=@time AND dbo.exams.toTime>=@time AND dbo.exams.venue=@venue and dbo.exams.Week=Cast(@week_no as varchar(50))


   select @courseTimeFrom= dbo.exams.fromTime from dbo.exams inner join dbo.courses on  dbo.exams.course  like '%'+dbo.courses.course+'%' where dbo.courses.program=@programme AND dbo.exams.day=@dayfinal AND dbo.exams.fromTime<=@time AND dbo.exams.toTime>=@time AND dbo.exams.venue=@venue and dbo.exams.Week=Cast(@week_no as varchar(50))
   select @courseTimeTo= dbo.exams.toTime from dbo.exams inner join dbo.courses on  dbo.exams.course  like '%'+dbo.courses.course+'%' where dbo.courses.program=@programme AND dbo.exams.day=@dayfinal AND dbo.exams.fromTime<=@time AND dbo.exams.toTime>=@time AND dbo.exams.venue=@venue and dbo.exams.Week=Cast(@week_no as varchar(50))
   
   
   select @validity= CASE 
					WHEN DATEDIFF(minute, dbo.exams.fromTime, @time)<=30 THEN 'VALID'
					ELSE 'INVALID'
					END
				
					from dbo.exams inner join dbo.courses on  dbo.exams.course  like '%'+dbo.courses.course+'%' where dbo.courses.program=@programme AND dbo.exams.day=@dayfinal AND dbo.exams.fromTime<=@time AND dbo.exams.toTime>=@time AND dbo.exams.venue=@venue and dbo.exams.Week=Cast(@week_no as varchar(50)) GROUP BY dbo.exams.fromTime


IF (SELECT ISNULL((select 1 from dbo.attendance_ue WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG' AND date=@date), 0))=1
BEGIN
UPDATE dbo.attendance_ue
SET  courseTimeFrom=@courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='UE',date=Cast(@date as varchar(50))
WHERE reg_no=@reg_no AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date
END 

ELSE
	BEGIN
		/*Check if student belong to the course*/
		IF (SELECT ISNULL((select 1 from dbo.USERINFO INNER JOIN dbo.DEPARTMENTS ON dbo.USERINFO.DEFAULTDEPTID=dbo.DEPARTMENTS.DEPTID INNER JOIN dbo.courses ON dbo.courses.program=dbo.DEPARTMENTS.DEPTNAME WHERE dbo.courses.course=@courseId AND dbo.USERINFO.NAME=@name AND dbo.courses.program=@programme), 0))=1
BEGIN
insert into dbo.attendance_ue
values ('DUMMY NAME','DUMMY REG',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME','DUMMY TITLE',Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'UE',Cast(@date as varchar(50)))


/*Partial complete data filling for students by themselves*/
insert into dbo.attendance_ue
SELECT dbo.USERINFO.NAME,dbo.USERINFO.SSN,dbo.courses.course,@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)) from dbo.USERINFO INNER JOIN dbo.DEPARTMENTS ON dbo.USERINFO.DEFAULTDEPTID=dbo.DEPARTMENTS.DEPTID INNER JOIN dbo.courses ON dbo.courses.program=dbo.DEPARTMENTS.DEPTNAME WHERE dbo.courses.course=@courseId

UPDATE attendance_ue
SET  courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='UE',date=Cast(@date as varchar(50))
WHERE reg_no=@reg_no AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date AND program=@programme

END

END


/*insert into dbo.attendance_ue
values (Cast(@name as varchar(50)),Cast(@reg_no as varchar(50)),Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,Cast(@day as varchar(50)),Cast(@title as varchar(50)),Cast(@programme as varchar(100)),'1',Cast(@validity as varchar(50)),'UE',Cast(@date as varchar(50)))
*/



END

/*CLASS */
ELSE IF (SELECT ISNULL((select 1 from dbo.timetables WHERE day=@dayfinal AND fromTime<=@time AND toTime>=@time AND venue=@venue), 0))=1
BEGIN

	IF (SELECT ISNULL((select 1 from dbo.combine_holidays WHERE day=@dayfinal AND fromTime<=@time AND toTime>=@time AND venue=@venue AND combined_date=@date), 0))=1
	BEGIN
Update dbo.system_errors
set [status]='in class ERROR1', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

	END

ELSE

BEGIN

   select @courseId=course from dbo.timetables WHERE day=@dayfinal AND fromTime<=@time AND toTime>=@time AND venue=@venue
   select @courseTimeFrom= fromTime from dbo.timetables WHERE day=@dayfinal AND fromTime<=@time AND toTime>=@time AND venue=@venue
   select @courseId_first_to=toTime from dbo.timetables WHERE day=@dayfinal AND fromTime<=@time AND toTime>=@time AND course=@courseId AND venue=@venue
   select @courseId_second_to=toTime from dbo.timetables WHERE day=@dayfinal AND fromTime=@courseId_first_to AND course=@courseId AND venue=@venue
   select @courseId_third_to=toTime from dbo.timetables WHERE day=@dayfinal AND fromTime=@courseId_second_to AND course=@courseId AND venue=@venue
   select @courseId_fourth_to=toTime from dbo.timetables WHERE day=@dayfinal AND fromTime=@courseId_third_to AND course=@courseId AND venue=@venue
   

    /*FOR DOUBLE */
   IF (SELECT ISNULL((select 1 from dbo.timetables WHERE day=@dayfinal AND fromTime=@courseId_first_to AND course=@courseId AND venue=@venue), 0))=1
   BEGIN
  
   select @courseTimeTo= toTime from dbo.timetables WHERE day=@dayfinal AND fromTime=@courseId_first_to AND course=@courseId AND venue=@venue

   END

    /*FOR TRIPLE */
   ELSE IF (SELECT ISNULL((select 1 from dbo.timetables WHERE day=@dayfinal AND fromTime=@courseId_second_to AND course=@courseId AND venue=@venue), 0))=1

   BEGIN
   select @courseTimeTo= toTime from dbo.timetables WHERE day=@dayfinal AND fromTime=@courseId_second_to AND course=@courseId AND venue=@venue

   END

    /*FOR QUADRUPLE */
   ELSE IF (SELECT ISNULL((select 1 from dbo.timetables WHERE day=@dayfinal AND fromTime=@courseId_third_to AND course=@courseId AND venue=@venue), 0))=1

   BEGIN
   select @courseTimeTo= toTime from dbo.timetables WHERE day=@dayfinal AND fromTime=@courseId_third_to AND course=@courseId AND venue=@venue

   END

 
   ELSE 

   /*FOR SINGLE */
   BEGIN

   select @courseTimeTo= toTime from dbo.timetables WHERE day=@dayfinal AND fromTime<=@time AND toTime>=@time AND venue=@venue

   END


  select @validity= CASE 
					WHEN DATEDIFF(minute, fromTime, @time)<=10 THEN 'VALID'
					ELSE 'INVALID'
					END
				
					from dbo.timetables WHERE course=@courseId AND fromTime<=@time AND toTime>=@time AND venue=@venue AND day=@dayfinal GROUP BY fromTime



	/*CODE FOR POSITION STARTS*/


IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%' AND technical_staff like '%'+@name+'%'), 0))=1
	BEGIN
	
	set @position='TECH'

    END

	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND Technical_Staff_2 like '%'+@name+'%'), 0))=1 
	BEGIN
	
	set @position='TECH'
	END


	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND Technical_Staff_3 like '%'+@name+'%'), 0))=1 
	BEGIN
	
set @position='TECH'
	END



	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND instructor like '%'+@name+'%'), 0))=1 
	BEGIN
	
	set @position='LECTURER'
	END


	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND Instructor_2 like '%'+@name+'%'), 0))=1 
	BEGIN
	
	set @position='LECTURER'
	END


	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND Instructor_3 like '%'+@name+'%'), 0))=1 
	BEGIN
	
	set @position='LECTURER'
	END


ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND Instructor_4 like '%'+@name+'%'), 0))=1 
	BEGIN
	
	set @position='LECTURER'
	END


	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND Instructor_5 like '%'+@name+'%'), 0))=1 
	BEGIN
	
	set @position='LECTURER'
	END

	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND Tutorial_Assistant like '%'+@name+'%'), 0))=1 
	BEGIN
	
	set @position='TUT'
	END
	
	ELSE
BEGIN
Update dbo.system_errors
set [status]='in Test ERROR0', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))
END


/*CODE FOR POSITION ENDS*/





IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG' AND date=@date), 0))=1
BEGIN
UPDATE dbo.attendance
SET  courseTimeFrom=@courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50))
WHERE reg_no=@reg_no AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date
END 

 /* Check for staff TECH its dummy*/
ELSE IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG STAFF TECH' AND program='DUMMY STAFF DEPT' AND date=@date), 0))=1

BEGIN
UPDATE dbo.attendance
SET name=@name, reg_no=@reg_no ,courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),position=@position
WHERE name like '%'+@name+'%' AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date
END

ELSE IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG STAFF TECH2' AND program='DUMMY STAFF DEPT' AND date=@date), 0))=1

BEGIN
UPDATE dbo.attendance
SET name=@name, reg_no=@reg_no ,courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),position=@position
WHERE name like '%'+@name+'%' AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date
END

ELSE IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG STAFF TECH3' AND program='DUMMY STAFF DEPT' AND date=@date), 0))=1

BEGIN
UPDATE dbo.attendance
SET name=@name, reg_no=@reg_no ,courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),position=@position
WHERE name like '%'+@name+'%' AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date
END

 
 /* Check for Tutorial assistant*/
ELSE IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG STAFF TUT' AND program='DUMMY STAFF DEPT' AND date=@date), 0))=1

BEGIN
UPDATE dbo.attendance
SET name=@name, reg_no=@reg_no,courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),position=@position
WHERE name like '%'+@name+'%' AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date
END


/* Check for staff*/

ELSE IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG STAFF' AND program='DUMMY STAFF DEPT' AND date=@date), 0))=1

BEGIN
UPDATE dbo.attendance
SET name=@name, reg_no=@reg_no,courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),position=@position
WHERE name like '%'+@name+'%' AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date
END

ELSE IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG STAFF2' AND program='DUMMY STAFF DEPT' AND date=@date), 0))=1

BEGIN
UPDATE dbo.attendance
SET name=@name, reg_no=@reg_no,courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),position=@position
WHERE name like '%'+@name+'%' AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date
END

ELSE IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG STAFF3' AND program='DUMMY STAFF DEPT' AND date=@date), 0))=1

BEGIN
UPDATE dbo.attendance
SET name=@name, reg_no=@reg_no,courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),position=@position
WHERE name like '%'+@name+'%' AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date
END

ELSE IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG STAFF4' AND program='DUMMY STAFF DEPT' AND date=@date), 0))=1

BEGIN
UPDATE dbo.attendance
SET name=@name, reg_no=@reg_no,courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),position=@position
WHERE name like '%'+@name+'%' AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date 
END

ELSE IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG STAFF5' AND program='DUMMY STAFF DEPT' AND date=@date), 0))=1

BEGIN
UPDATE dbo.attendance
SET name=@name, reg_no=@reg_no,courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),position=@position
WHERE name like '%'+@name+'%' AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date
END


ELSE
BEGIN
/*DUMMY FILLING*/
/*CHECKS IF STUDENT BELONGS TO THE COURSE*/
IF (SELECT ISNULL((select 1 from dbo.USERINFO INNER JOIN dbo.DEPARTMENTS ON dbo.USERINFO.DEFAULTDEPTID=dbo.DEPARTMENTS.DEPTID INNER JOIN dbo.courses ON dbo.courses.program=dbo.DEPARTMENTS.DEPTNAME WHERE dbo.courses.course=@courseId AND dbo.USERINFO.NAME=@name AND dbo.courses.program=@programme), 0))=1
BEGIN
insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME','DUMMY TITLE',Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

/*Student also fills dummy for staff*/
/*Check whether they exist first*/

IF (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.timetables ON dbo.lecturers.course=dbo.timetables.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.instructor IS NOT NULL AND dbo.timetables.day=@dayfinal AND dbo.timetables.fromTime<=@time AND dbo.timetables.toTime>=@time AND dbo.timetables.venue=@venue AND dbo.timetables.criteria='Lecture'), 0))=1
	BEGIN
		insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

	END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in class ERROR2', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.timetables ON dbo.lecturers.course=dbo.timetables.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.Instructor_2 IS NOT NULL AND dbo.timetables.day=@dayfinal AND dbo.timetables.fromTime<=@time AND dbo.timetables.toTime>=@time AND dbo.timetables.venue=@venue AND dbo.timetables.criteria='Lecture'), 0))=1 
	BEGIN

	insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF2',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')
   
END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in class ERROR3', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.timetables ON dbo.lecturers.course=dbo.timetables.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.Instructor_3 IS NOT NULL AND dbo.timetables.day=@dayfinal AND dbo.timetables.fromTime<=@time AND dbo.timetables.toTime>=@time AND dbo.timetables.venue=@venue AND dbo.timetables.criteria='Lecture'), 0))=1 
	BEGIN

	insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF3',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')
   
END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in class ERROR4', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.timetables ON dbo.lecturers.course=dbo.timetables.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.Instructor_4 IS NOT NULL AND dbo.timetables.day=@dayfinal AND dbo.timetables.fromTime<=@time AND dbo.timetables.toTime>=@time AND dbo.timetables.venue=@venue AND dbo.timetables.criteria='Lecture'), 0))=1 
	BEGIN

	insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF4',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')
   
END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in class ERROR5', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.timetables ON dbo.lecturers.course=dbo.timetables.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.Instructor_5 IS NOT NULL AND dbo.timetables.day=@dayfinal AND dbo.timetables.fromTime<=@time AND dbo.timetables.toTime>=@time AND dbo.timetables.venue=@venue AND dbo.timetables.criteria='Lecture'), 0))=1 
	BEGIN

	insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF5',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')
   
END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in class ERROR6', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END

IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.timetables ON dbo.lecturers.course=dbo.timetables.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.Tutorial_Assistant IS NOT NULL AND dbo.timetables.day=@dayfinal AND dbo.timetables.fromTime<=@time AND dbo.timetables.toTime>=@time AND dbo.timetables.venue=@venue AND dbo.timetables.criteria='Tutorial'), 0))=1 
	BEGIN

	insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF TUT',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')
   
END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in class ERROR7', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.timetables ON dbo.lecturers.course=dbo.timetables.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.technical_staff IS NOT NULL AND dbo.timetables.day=@dayfinal AND dbo.timetables.fromTime<=@time AND dbo.timetables.toTime>=@time AND dbo.timetables.venue=@venue AND dbo.timetables.criteria='Lab'), 0))=1 
	BEGIN

	insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF TECH',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')
   
END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in class ERROR8', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.timetables ON dbo.lecturers.course=dbo.timetables.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.Technical_Staff_2 IS NOT NULL AND dbo.timetables.day=@dayfinal AND dbo.timetables.fromTime<=@time AND dbo.timetables.toTime>=@time AND dbo.timetables.venue=@venue AND dbo.timetables.criteria='Lab'), 0))=1 
	BEGIN

	insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF TECH2',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')
   
END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in class ERROR9', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.timetables ON dbo.lecturers.course=dbo.timetables.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.Technical_Staff_3 IS NOT NULL AND dbo.timetables.day=@dayfinal AND dbo.timetables.fromTime<=@time AND dbo.timetables.toTime>=@time AND dbo.timetables.venue=@venue AND dbo.timetables.criteria='Lab'), 0))=1 
	BEGIN
	insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF TECH3',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')
   
END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in class ERROR10', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


END


ELSE

BEGIN
Update dbo.system_errors
set [status]='in class ERROR11', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END

/*Dummy filling for staff BY themselves*/

IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%' AND technical_staff like '%'+@name+'%'), 0))=1
	BEGIN
		insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF TECH',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

/*Dummy filling for students BY staff*/
insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME','DUMMY TITLE',Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')


    END


	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND Technical_Staff_2 like '%'+@name+'%'), 0))=1 
	BEGIN
	
			insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF TECH2',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

/*Dummy filling for students BY staff*/
insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME','DUMMY TITLE',Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

	END


	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND Technical_Staff_3 like '%'+@name+'%'), 0))=1 
	BEGIN
	
			insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF TECH3',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

/*Dummy filling for students BY staff*/
insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME','DUMMY TITLE',Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

	END



	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND instructor like '%'+@name+'%'), 0))=1 
	BEGIN
	
			insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

/*Dummy filling for students BY staff*/
insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME','DUMMY TITLE',Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

	END


	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND Instructor_2 like '%'+@name+'%'), 0))=1 
	BEGIN
	
			insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF2',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

/*Dummy filling for students BY staff*/
insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME','DUMMY TITLE',Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

	END


	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND Instructor_3 like '%'+@name+'%'), 0))=1 
	BEGIN
	
			insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF3',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

/*Dummy filling for students BY staff*/
insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME','DUMMY TITLE',Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

	END


ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND Instructor_4 like '%'+@name+'%'), 0))=1 
	BEGIN
	
			insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF4',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

/*Dummy filling for students BY staff*/
insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME','DUMMY TITLE',Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

	END


	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND Instructor_5 like '%'+@name+'%'), 0))=1 
	BEGIN
	
			insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF5',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

/*Dummy filling for students BY staff*/
insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME','DUMMY TITLE',Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

	END

	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%'AND Tutorial_Assistant like '%'+@name+'%'), 0))=1 
	BEGIN
	
			insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG STAFF TUT',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME',Cast(@title as varchar(50)),'DUMMY STAFF DEPT',0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

/*Dummy filling for students BY staff*/
insert into dbo.attendance
values ('DUMMY NAME','DUMMY REG',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'DUMMY DATETIME','DUMMY TITLE',Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

	END



ELSE

BEGIN
Update dbo.system_errors
set [status]='in class ERROR12', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END

/*partial complete data filling for students by themselves*/

IF (SELECT ISNULL((select 1 from dbo.USERINFO INNER JOIN dbo.DEPARTMENTS ON dbo.USERINFO.DEFAULTDEPTID=dbo.DEPARTMENTS.DEPTID INNER JOIN dbo.courses ON dbo.courses.program=dbo.DEPARTMENTS.DEPTNAME WHERE dbo.courses.course=@courseId AND dbo.USERINFO.NAME=@name AND dbo.courses.program=@programme), 0))=1
BEGIN
insert into dbo.attendance
SELECT dbo.USERINFO.NAME,dbo.USERINFO.SSN,dbo.courses.course,@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.USERINFO INNER JOIN dbo.DEPARTMENTS ON dbo.USERINFO.DEFAULTDEPTID=dbo.DEPARTMENTS.DEPTID INNER JOIN dbo.courses ON dbo.courses.program=dbo.DEPARTMENTS.DEPTNAME WHERE dbo.courses.course=@courseId

UPDATE attendance
SET  courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50))
WHERE reg_no=@reg_no AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date AND program=@programme
END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in class ERROR12b', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END

/*Partial complete data filling for staff by students*/



/*Check if the person associates with the course */
/*If the person is a student*/
IF (SELECT ISNULL((select 1 from dbo.USERINFO INNER JOIN dbo.DEPARTMENTS ON dbo.USERINFO.DEFAULTDEPTID=dbo.DEPARTMENTS.DEPTID INNER JOIN dbo.courses ON dbo.courses.program=dbo.DEPARTMENTS.DEPTNAME WHERE dbo.courses.course=@courseId AND dbo.USERINFO.NAME=@name AND dbo.courses.program=@programme), 0))=1
BEGIN
 
/*CODE STARTS*/



IF (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.timetables ON dbo.lecturers.course=dbo.timetables.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.instructor IS NOT NULL AND dbo.timetables.day=@dayfinal AND dbo.timetables.fromTime<=@time AND dbo.timetables.toTime>=@time AND dbo.timetables.venue=@venue AND dbo.timetables.criteria='Lecture'), 0))=1
	BEGIN
Insert into dbo.attendance
SELECT instructor,'STAFF partial reg',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.lecturers WHERE course like '%'+@courseId+'%'

	END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in class ERROR13', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.timetables ON dbo.lecturers.course=dbo.timetables.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.Instructor_2 IS NOT NULL AND dbo.timetables.day=@dayfinal AND dbo.timetables.fromTime<=@time AND dbo.timetables.toTime>=@time AND dbo.timetables.venue=@venue AND dbo.timetables.criteria='Lecture'), 0))=1 
	BEGIN

Insert into dbo.attendance
SELECT Instructor_2,'STAFF2 partial reg',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.lecturers WHERE course like '%'+@courseId+'%'
END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in class ERROR14', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.timetables ON dbo.lecturers.course=dbo.timetables.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.Instructor_3 IS NOT NULL AND dbo.timetables.day=@dayfinal AND dbo.timetables.fromTime<=@time AND dbo.timetables.toTime>=@time AND dbo.timetables.venue=@venue AND dbo.timetables.criteria='Lecture'), 0))=1 
	BEGIN

Insert into dbo.attendance
SELECT Instructor_3,'STAFF3 partial reg',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.lecturers WHERE course like '%'+@courseId+'%'
END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in class ERROR15', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.timetables ON dbo.lecturers.course=dbo.timetables.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.Instructor_4 IS NOT NULL AND dbo.timetables.day=@dayfinal AND dbo.timetables.fromTime<=@time AND dbo.timetables.toTime>=@time AND dbo.timetables.venue=@venue AND dbo.timetables.criteria='Lecture'), 0))=1 
	BEGIN

Insert into dbo.attendance
SELECT Instructor_4,'STAFF4 partial reg',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.lecturers WHERE course like '%'+@courseId+'%'
END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in class ERROR16', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.timetables ON dbo.lecturers.course=dbo.timetables.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.Instructor_5 IS NOT NULL AND dbo.timetables.day=@dayfinal AND dbo.timetables.fromTime<=@time AND dbo.timetables.toTime>=@time AND dbo.timetables.venue=@venue AND dbo.timetables.criteria='Lecture'), 0))=1 
	BEGIN

Insert into dbo.attendance
SELECT Instructor_5,'STAFF5 partial reg',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.lecturers WHERE course like '%'+@courseId+'%' 
END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in class ERROR17', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END

IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.timetables ON dbo.lecturers.course=dbo.timetables.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.Tutorial_Assistant IS NOT NULL AND dbo.timetables.day=@dayfinal AND dbo.timetables.fromTime<=@time AND dbo.timetables.toTime>=@time AND dbo.timetables.venue=@venue AND dbo.timetables.criteria='Tutorial'), 0))=1 
	BEGIN

Insert into dbo.attendance
SELECT Tutorial_Assistant,'STAFF TUT partial reg',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.lecturers WHERE course like '%'+@courseId+'%'  
END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in class ERROR18', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.timetables ON dbo.lecturers.course=dbo.timetables.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.technical_staff IS NOT NULL AND dbo.timetables.day=@dayfinal AND dbo.timetables.fromTime<=@time AND dbo.timetables.toTime>=@time AND dbo.timetables.venue=@venue AND dbo.timetables.criteria='Lab'), 0))=1 
	BEGIN

Insert into dbo.attendance
SELECT technical_staff,'TECH STAFF partial reg',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.lecturers WHERE course like '%'+@courseId+'%'

END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in class ERROR19', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.timetables ON dbo.lecturers.course=dbo.timetables.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.Technical_Staff_2 IS NOT NULL AND dbo.timetables.day=@dayfinal AND dbo.timetables.fromTime<=@time AND dbo.timetables.toTime>=@time AND dbo.timetables.venue=@venue AND dbo.timetables.criteria='Lab'), 0))=1 
	BEGIN

Insert into dbo.attendance
SELECT Technical_Staff_2,'TECH2 STAFF partial reg',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.lecturers WHERE course like '%'+@courseId+'%'

END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in class ERROR20', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


IF  (SELECT ISNULL((select 1 FROM dbo.lecturers INNER JOIN dbo.timetables ON dbo.lecturers.course=dbo.timetables.course WHERE dbo.lecturers.course like '%'+@courseId+'%'AND dbo.lecturers.Technical_Staff_3 IS NOT NULL AND dbo.timetables.day=@dayfinal AND dbo.timetables.fromTime<=@time AND dbo.timetables.toTime>=@time AND dbo.timetables.venue=@venue AND dbo.timetables.criteria='Lab'), 0))=1 
	BEGIN
Insert into dbo.attendance
SELECT technical_staff_3,'TECH3 STAFF partial reg',Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.lecturers WHERE course like '%'+@courseId+'%'
  
END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in class ERROR21', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


/*CODE ENDS*/

 

END

ELSE
BEGIN

Update dbo.system_errors
set [status]='in class ERROR22', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


/*Partial complete data filling for staff by themselves*/


IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%' AND technical_staff like '%'+@name+'%'), 0))=1
	BEGIN
		insert into dbo.attendance
values (Cast(@name as varchar(50)),Cast(@reg_no as varchar(50)),Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL',Cast(@title as varchar(50)),Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')

UPDATE dbo.attendance
SET courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),position=@position
WHERE reg_no=@reg_no AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date AND program=@programme

/*Partial complete data filling for students by staff*/
/*Check if there was any student who signed in b4*/
IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG' AND date=@date), 0))=1
BEGIN
insert into dbo.attendance
SELECT dbo.USERINFO.NAME,dbo.USERINFO.SSN,dbo.courses.course,@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.USERINFO INNER JOIN dbo.DEPARTMENTS ON dbo.USERINFO.DEFAULTDEPTID=dbo.DEPARTMENTS.DEPTID INNER JOIN dbo.courses ON dbo.courses.program=dbo.DEPARTMENTS.DEPTNAME WHERE dbo.courses.course=@courseId

END 

ELSE

	BEGIN

	Update dbo.system_errors
set [status]='in class ERROR23', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))


	END


    END


	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%' AND Technical_Staff_2 like '%'+@name+'%'), 0))=1 
	BEGIN
	
		insert into dbo.attendance
values (Cast(@name as varchar(50)),Cast(@reg_no as varchar(50)),Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL',Cast(@title as varchar(50)),Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')


UPDATE dbo.attendance
SET courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),position=@position
WHERE reg_no=@reg_no AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date AND program=@programme

/*Partial complete data filling for students by staff*/
/*Check if there was any student who signed in b4*/
IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG' AND date=@date), 0))=1
BEGIN
insert into dbo.attendance
SELECT dbo.USERINFO.NAME,dbo.USERINFO.SSN,dbo.courses.course,@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.USERINFO INNER JOIN dbo.DEPARTMENTS ON dbo.USERINFO.DEFAULTDEPTID=dbo.DEPARTMENTS.DEPTID INNER JOIN dbo.courses ON dbo.courses.program=dbo.DEPARTMENTS.DEPTNAME WHERE dbo.courses.course=@courseId

END 

ELSE

	BEGIN

	Update dbo.system_errors
set [status]='in class ERROR24', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))


	END


	END



	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%' AND Technical_Staff_3 like '%'+@name+'%'), 0))=1 
	BEGIN
	
		insert into dbo.attendance
values (Cast(@name as varchar(50)),Cast(@reg_no as varchar(50)),Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL',Cast(@title as varchar(50)),Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')


UPDATE dbo.attendance
SET courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),position=@position
WHERE reg_no=@reg_no AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date AND program=@programme

/*Partial complete data filling for students by staff*/
/*Check if there was any student who signed in b4*/
IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG' AND date=@date), 0))=1
BEGIN
insert into dbo.attendance
SELECT dbo.USERINFO.NAME,dbo.USERINFO.SSN,dbo.courses.course,@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.USERINFO INNER JOIN dbo.DEPARTMENTS ON dbo.USERINFO.DEFAULTDEPTID=dbo.DEPARTMENTS.DEPTID INNER JOIN dbo.courses ON dbo.courses.program=dbo.DEPARTMENTS.DEPTNAME WHERE dbo.courses.course=@courseId

END 

ELSE

	BEGIN

	Update dbo.system_errors
set [status]='in class ERROR25', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))


	END


	END


	ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%' AND instructor like '%'+@name+'%'), 0))=1 
	BEGIN
	
		insert into dbo.attendance
values (Cast(@name as varchar(50)),Cast(@reg_no as varchar(50)),Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL',Cast(@title as varchar(50)),Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')


UPDATE dbo.attendance
SET courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),position=@position
WHERE reg_no=@reg_no AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date AND program=@programme

/*Partial complete data filling for students by staff*/
/*Check if there was any student who signed in b4*/
IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG' AND date=@date), 0))=1
BEGIN
insert into dbo.attendance
SELECT dbo.USERINFO.NAME,dbo.USERINFO.SSN,dbo.courses.course,@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.USERINFO INNER JOIN dbo.DEPARTMENTS ON dbo.USERINFO.DEFAULTDEPTID=dbo.DEPARTMENTS.DEPTID INNER JOIN dbo.courses ON dbo.courses.program=dbo.DEPARTMENTS.DEPTNAME WHERE dbo.courses.course=@courseId

END 

ELSE

	BEGIN

	Update dbo.system_errors
set [status]='in class ERROR26', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))


	END


	END


		ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%' AND Instructor_2 like '%'+@name+'%'), 0))=1 
	BEGIN
	
		insert into dbo.attendance
values (Cast(@name as varchar(50)),Cast(@reg_no as varchar(50)),Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL',Cast(@title as varchar(50)),Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')


UPDATE dbo.attendance
SET courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),position=@position
WHERE reg_no=@reg_no AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date AND program=@programme

/*Partial complete data filling for students by staff*/
/*Check if there was any student who signed in b4*/
IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG' AND date=@date), 0))=1
BEGIN
insert into dbo.attendance
SELECT dbo.USERINFO.NAME,dbo.USERINFO.SSN,dbo.courses.course,@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.USERINFO INNER JOIN dbo.DEPARTMENTS ON dbo.USERINFO.DEFAULTDEPTID=dbo.DEPARTMENTS.DEPTID INNER JOIN dbo.courses ON dbo.courses.program=dbo.DEPARTMENTS.DEPTNAME WHERE dbo.courses.course=@courseId

END 

ELSE

	BEGIN

	Update dbo.system_errors
set [status]='in class ERROR27', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))


	END


	END


		ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%' AND Instructor_3 like '%'+@name+'%'), 0))=1 
	BEGIN
	
		insert into dbo.attendance
values (Cast(@name as varchar(50)),Cast(@reg_no as varchar(50)),Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL',Cast(@title as varchar(50)),Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')


UPDATE dbo.attendance
SET courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),position=@position
WHERE reg_no=@reg_no AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date AND program=@programme

/*Partial complete data filling for students by staff*/
/*Check if there was any student who signed in b4*/
IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG' AND date=@date), 0))=1
BEGIN
insert into dbo.attendance
SELECT dbo.USERINFO.NAME,dbo.USERINFO.SSN,dbo.courses.course,@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.USERINFO INNER JOIN dbo.DEPARTMENTS ON dbo.USERINFO.DEFAULTDEPTID=dbo.DEPARTMENTS.DEPTID INNER JOIN dbo.courses ON dbo.courses.program=dbo.DEPARTMENTS.DEPTNAME WHERE dbo.courses.course=@courseId

END 

ELSE

	BEGIN

	Update dbo.system_errors
set [status]='in class ERROR28', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))


	END


	END



		ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%' AND Instructor_4 like '%'+@name+'%'), 0))=1 
	BEGIN
	
		insert into dbo.attendance
values (Cast(@name as varchar(50)),Cast(@reg_no as varchar(50)),Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL',Cast(@title as varchar(50)),Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')


UPDATE dbo.attendance
SET courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),position=@position
WHERE reg_no=@reg_no AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date AND program=@programme

/*Partial complete data filling for students by staff*/
/*Check if there was any student who signed in b4*/
IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG' AND date=@date), 0))=1
BEGIN
insert into dbo.attendance
SELECT dbo.USERINFO.NAME,dbo.USERINFO.SSN,dbo.courses.course,@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.USERINFO INNER JOIN dbo.DEPARTMENTS ON dbo.USERINFO.DEFAULTDEPTID=dbo.DEPARTMENTS.DEPTID INNER JOIN dbo.courses ON dbo.courses.program=dbo.DEPARTMENTS.DEPTNAME WHERE dbo.courses.course=@courseId

END 

ELSE

	BEGIN

	Update dbo.system_errors
set [status]='in class ERROR29', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))


	END


	END


		ELSE IF (SELECT ISNULL((select 1 FROM dbo.lecturers WHERE course like '%'+@courseId+'%' AND Instructor_5 like '%'+@name+'%'), 0))=1 
	BEGIN
	
		insert into dbo.attendance
values (Cast(@name as varchar(50)),Cast(@reg_no as varchar(50)),Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,'NULL',Cast(@title as varchar(50)),Cast(@programme as varchar(100)),0,Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')


UPDATE dbo.attendance
SET courseTimeFrom= @courseTimeFrom, courseTimeTo= @courseTimeTo,datetime=Cast(@day as varchar(50)),title=Cast(@title as varchar(50)),program=Cast(@programme as varchar(50)),status=1,validity=@validity,category='CLASS',date=Cast(@date as varchar(50)),position=@position
WHERE reg_no=@reg_no AND courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND date=@date AND program=@programme

/*Partial complete data filling for students by staff*/
/*Check if there was any student who signed in b4*/
IF (SELECT ISNULL((select 1 from dbo.attendance WHERE courseId=@courseId AND courseTimeFrom=@courseTimeFrom AND courseTimeTo=@courseTimeTo AND reg_no='DUMMY REG' AND date=@date), 0))=1
BEGIN
insert into dbo.attendance
SELECT dbo.USERINFO.NAME,dbo.USERINFO.SSN,dbo.courses.course,@courseTimeFrom,@courseTimeTo,'NULL','NULL',Cast(@programme as varchar(100)),0,'NULL','NULL',Cast(@date as varchar(50)),'NULL','MIMI' from dbo.USERINFO INNER JOIN dbo.DEPARTMENTS ON dbo.USERINFO.DEFAULTDEPTID=dbo.DEPARTMENTS.DEPTID INNER JOIN dbo.courses ON dbo.courses.program=dbo.DEPARTMENTS.DEPTNAME WHERE dbo.courses.course=@courseId

END 

ELSE

	BEGIN

	Update dbo.system_errors
set [status]='in class ERROR30', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))


	END


	END



ELSE

BEGIN
Update dbo.system_errors
set [status]='in class ERROR31', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END


/*insert into dbo.attendance
values (Cast(@name as varchar(50)),Cast(@reg_no as varchar(50)),Cast(@courseId as varchar(50)),@courseTimeFrom,@courseTimeTo,Cast(@day as varchar(50)),Cast(@title as varchar(50)),Cast(@programme as varchar(100)),'1',Cast(@validity as varchar(50)),'CLASS',Cast(@date as varchar(50)),'NULL','MIMI')*/

END



END


END

ELSE

BEGIN


Update dbo.system_errors
set [status]='Fail all conditions ERROR', [date]=Cast(@date as varchar(50)),[time]=Cast(@time as varchar(50))

END

END
go

